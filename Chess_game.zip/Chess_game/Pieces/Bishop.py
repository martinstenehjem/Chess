from Chess2 import Board, Piece


class Bishop(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()
        self.value = 3

    def get_name(self):
        return self.color + " Bishop"

    def capture(self):
        pass

    def legal_moves(self):
        # creating a list of possible moves
        moves = []
        # Moves bishop north-west
        left = Board.columns.index(self.square[0]) - 1  # column index of the column left of bishop
        forward = int(self.square[1]) + 1  # row index of the row in front of bishop
        if left >= 0 and Board.columns[left] + str(forward) in Board.square_dict:  # checks if front-left on the board
            while Board.square_dict[Board.columns[left] + str(forward)] is None:
                moves.append(Board.columns[left] + str(forward))
                left -= 1
                forward += 1
                if left<0 or Board.columns[left] + str(forward) not in Board.square_dict:
                    break
        # Moves bishop south-west
        left = Board.columns.index(self.square[0]) - 1  # column index of the column left of bishop
        backward = int(self.square[1]) - 1  # row index of the row behind of bishop
        if left >= 0 and Board.columns[left] + str(backward) in Board.square_dict:  # checks if rear-left on the board
            while Board.square_dict[Board.columns[left] + str(backward)] is None:
                moves.append(Board.columns[left] + str(backward))
                left -= 1
                backward -= 1
                if left<0 or Board.columns[left] + str(backward) not in Board.square_dict:
                    break
        # Moves bishop north-east
        right = Board.columns.index(self.square[0]) + 1  # column index of the column right of bishop
        forward = int(self.square[1]) + 1  # row index of the row in front of bishop
        if right < 8 and Board.columns[right] + str(forward) in Board.square_dict:  # front-right otb
            while Board.square_dict[Board.columns[right] + str(forward)] is None:
                moves.append(Board.columns[right] + str(forward))
                right += 1
                forward += 1
                if right>7 or Board.columns[right] + str(forward) not in Board.square_dict:
                    break
        # Moves bishop south-east
        right = Board.columns.index(self.square[0]) + 1  # column index of the column right of bishop
        backward = int(self.square[1]) - 1  # row index of the row in front of bishop
        if right < 8 and Board.columns[right] + str(backward) in Board.square_dict:  # rear_right otb
            while Board.square_dict[Board.columns[right] + str(backward)] is None:
                moves.append(Board.columns[right] + str(backward))
                right += 1
                backward -= 1
                if right>7 or Board.columns[right] + str(backward) not in Board.square_dict:
                    break
        return moves
