from Chess2 import Board, Piece


class Pawn(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()
        self.value = 1

    def get_name(self):
        return self.color + " Pawn"

    def capture(self):
        moves = []
        left = Board.columns.index(self.square[0]) - 1
        right = Board.columns.index(self.square[0]) + 1
        if self.color == "white":
            if left>=0:
                attack_left = Board.columns[left] + str(int(self.square[1]) + 1)
                if Board.square_dict[attack_left] is not None and Board.square_dict[attack_left][0] != self.color[0]:
                    moves.append(attack_left)
            if right<8:
                attack_right = Board.columns[right] + str(int(self.square[1]) + 1)
                if Board.square_dict[attack_right] is not None and Board.square_dict[attack_right][0] != self.color[0]:
                    moves.append(attack_right)
        else:
            if left>=0:
                attack_left = Board.columns[left] + str(int(self.square[1]) - 1)
                if Board.square_dict[attack_left] is not None and Board.square_dict[attack_left][0] != self.color[0]:
                    moves.append(attack_left)
            if right<8:
                attack_right = Board.columns[right] + str(int(self.square[1]) - 1)
                if Board.square_dict[attack_right] is not None and Board.square_dict[attack_right][0] != self.color[0]:
                    moves.append(attack_right)
        return moves

    def legal_moves(self):
        # creating a list of possible moves
        moves = []
        if self.color == "white":
            new_square1 = self.square[0] + str(int(self.square[1]) + 1)
            new_square2 = self.square[0] + str(int(self.square[1]) + 2)
            start = "2"
        else:
            new_square1 = self.square[0] + str(int(self.square[1]) - 1)
            new_square2 = self.square[0] + str(int(self.square[1]) - 2)
            start = "7"
        # Moving one square forward
        if int(new_square1[1])<9 and Board.square_dict[new_square1] is None:
            moves.append(new_square1)
        # Moving two squares forward (only in its starting position)
        if (self.square[1] == start) and Board.square_dict[new_square1] is None and Board.square_dict[new_square2] is None:
            moves.append(new_square2)

        return moves + self.capture()
