from abc import abstractmethod, ABC
from Chess2 import Board


class Piece(ABC):
    def __init__(self, square):
        self.square = square

    @abstractmethod
    def get_name(self):
        pass

    def move(self, new_square):
        if new_square in self.legal_moves():
            Board.square_dict[self.square] = None
            self.square = new_square
            Board.square_dict[self.square] = self.get_name()
        else:
            print("sorry, illegal move")

    @abstractmethod
    def capture(self):
        pass

    @abstractmethod
    def legal_moves(self):
        pass