from Chess2 import Board, Piece
import Rook, Bishop


class Queen(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()
        self.value = 10

    def get_name(self):
        return self.color + " Queen"

    def capture(self):
        pass

    def legal_moves(self):
        return Bishop.legal_moves(self) + Rook.legal_moves(self)
