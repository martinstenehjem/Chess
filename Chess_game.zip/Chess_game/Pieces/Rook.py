from Chess2 import Board, Piece


class Rook(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()
        self.value = 5

    def get_name(self):
        return self.color + " Rook"

    def capture(self):
        pass

    def legal_moves(self):
        # creating a list of possible moves
        moves = []
        # Moving rook forward
        forward = int(self.square[1]) + 1
        if self.square[0] + str(forward) in Board.square_dict:
            while Board.square_dict[self.square[0] + str(forward)] is None:  # while no pieces are in the way
                moves.append(self.square[0] + str(forward))
                forward += 1
                if self.square[0] + str(forward) not in Board.square_dict:
                    break
        # Moving rook backwards
        backward = int(self.square[1]) - 1
        if self.square[0] + str(backward) in Board.square_dict:
            while Board.square_dict[self.square[0] + str(backward)] is None:  # while no pieces are in the way
                moves.append(self.square[0] + str(backward))
                backward -= 1
                if self.square[0] + str(backward) not in Board.square_dict:
                    break
        # Moving rook to the right
        right = Board.columns.index(self.square[0]) + 1
        if right < 8:
            while Board.square_dict[Board.columns[right] + self.square[1]] is None:  # while no pieces are in the way
                moves.append(Board.columns[right] + self.square[1])
                right += 1
                if right>7:
                    break
        # Moves rook to the left
        left = Board.columns.index(self.square[0]) - 1  # column left of the rook
        if left >= 0:  # if square left of rook on board
            while Board.square_dict[Board.columns[left] + self.square[1]] is None:  # while no pieces are in the way
                moves.append(Board.columns[left] + self.square[1])
                left -= 1
                if left<0:
                    break
        return moves
