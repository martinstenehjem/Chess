from Chess2 import Board, Piece


class King(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()

    def get_name(self):
        return self.color + " King"

    def capture(self):
        pass

    def legal_moves(self):
        moves = []
        col = Board.columns.index(self.square[0])
        row = int(self.square[1])
        left = col - 1
        right = col + 1
        candidates = []
        if left>=0:
            candidates.append(Board.columns[left] + (str(row)))
            if row<8:
                candidates.append(Board.columns[left] + (str(row+1)))
            if row>1:
                candidates.append(Board.columns[left] + (str(row-1)))
        if right<8:
            candidates.append(Board.columns[right] + (str(row)))
            if row<8:
                candidates.append(Board.columns[right] + (str(row+1)))
            if row>1:
                candidates.append(Board.columns[right] + (str(row-1)))
        if row+1<9:
            candidates.append(Board.columns[col] + (str(row+1)))
        if row-1>0:
            candidates.append(Board.columns[col] + (str(row-1)))
        for move in candidates:
            if Board.square_dict[move] is None:
                moves.append(move)
            elif Board.square_dict[move][0] != self.color[0]:
                moves.append(move)
        return moves
