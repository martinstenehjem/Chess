from Chess2 import Board, Piece


class Knight(Piece):
    def __init__(self, color, square):
        super().__init__(square)
        self.color = color
        self.square = square
        Board.square_dict[square] = self.get_name()
        self.value = 3

    def get_name(self):
        return self.color + " Knight"

    def capture(self):
        pass

    def legal_moves(self):
        moves = []
        col = Board.columns.index(self.square[0])
        row = int(self.square[1])
        left = col - 1
        left2 = col - 2
        right = col + 1
        right2 = col + 2
        candidates = []
        if left >= 0 and row < 7:
            candidates.append(Board.columns[left] + (str(row + 2)))
        if left >= 0 and row > 2:
            candidates.append(Board.columns[left] + (str(row - 2)))
        if left2 >= 0 and row < 8:
            candidates.append(Board.columns[left2] + (str(row + 1)))
        if left2 >= 0 and row > 1:
            candidates.append(Board.columns[left2] + (str(row - 1)))
        if right < 8 and row < 7:
            candidates.append(Board.columns[right] + (str(row + 2)))
        if right < 8 and row > 2:
            candidates.append(Board.columns[right] + (str(row - 2)))
        if right2 < 8 and row < 8:
            candidates.append(Board.columns[right2] + (str(row + 1)))
        if right2 < 8 and row > 1:
            candidates.append(Board.columns[right2] + (str(row - 1)))
        for move in candidates:
            if Board.square_dict[move] is None:
                moves.append(move)
            else:
                if Board.square_dict[move][0] != self.color[0]:
                    moves.append(move)
        return moves
