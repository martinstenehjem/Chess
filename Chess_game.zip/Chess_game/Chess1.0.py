# My chessboard! This chess board can be used to play multiplayer chess against a friend.

# In version 1.0, I have made the foundation for making a board and moving some pieces.  

class Board:
    def __init__(self):
        self.columns = [col for col in "abcdefgh"]
        self.rows = [row for row in range(1, 9)]
        self.squares = {}
        squares = [column + str(row) for row in self.rows for column in self.columns]
        for square in squares:
            self.squares[square] = None
        self.pawns = [column + "2" for i in range(1, 9) for column in self.columns]
        self.rooks = ["a1", "h1"]
        self.knights = ["b1", "g1"]
        self.bishops = ["c1", "f1"]
        self.queens = ["d1"]
        self.kings = ["e1"]
        self.pieces_starting_position()

    def pieces_starting_position(self):
        for pawns in self.pawns:
            self.squares[pawns] = "PAWN"
        for rooks in self.rooks:
            self.squares[rooks] = "♜"
        for knights in self.knights:
            self.squares[knights] = "♞"
        for queen in self.queens:
            self.squares[queen] = "♛"
        for king in self.kings:
            self.squares[king] = "♚"

    def pawn_moves(self, square):
        # creating a list of possible moves
        moves = []
        # Moving one square forward
        # new_square1 = self.columns[self.columns.index(square[0]) + 1] + square[1]
        new_square1 = square[0] + str(int(square[1]) + 1)
        if self.squares[new_square1] is None:
            moves.append(new_square1)
        # Moving two squares forward (only in its starting position)
        if (square[1] == "2") and self.squares[square[0] + str(int(square[1]) + 1)] is None:
            new_square2 = square[0] + str(int(square[1]) + 2)
            moves.append(new_square2)
        return moves

    def rook_moves(self, square):
        # creating a list of possible moves
        moves = []
        # Moving rook forward
        forward = int(square[1]) + 1
        if square[0] + str(forward) in self.squares:
            while self.squares[square[0] + str(forward)] is None:
                forward += 1
                if square[0] + str(forward) not in self.squares:
                    break
                moves.append(square[0] + str(forward))
        # Moving rook backwards
        backward = int(square[1]) - 1
        if square[0] + str(backward) in self.squares:
            while self.squares[square[0] + str(backward)] is None:
                backward -= 1
                if square[0] + str(backward) not in self.squares:
                    break
                moves.append(square[0] + str(backward))
        # Moving rook to the right
        right = self.columns.index(square[0]) + 1
        if right < len(self.columns):
            while self.squares[self.columns[right] + square[1]] is None:
                right += 1
                if self.columns[right] + square[1] not in self.squares:
                    break
                moves.append(self.columns[right] + square[1])
        # Moves rook to the left
        left = self.columns.index(square[0]) - 1  # column left of the rook
        if self.columns[left] + square[1] in self.squares and left >= 0:  # if square left of the rook is on the board
            while self.squares[self.columns[left] + square[1]] is None:  # while there are no pieces in the way
                left -= 1
                if self.columns[left] + square[1] not in self.squares:
                    break
                moves.append(self.columns[left] + square[1])
        return moves

    def bishop_moves(self, square):
        # creating a list of possible moves
        moves = []
        left = self.columns.index(square[0]) - 1  # column index of the column left of bishop
        forward = int(square[1]) + 1  # row index of the row in front of bishop
        if self.columns[left] + str(forward) in self.squares and left >= 0:  # checks if front-left is inside the board
            while self.squares[self.columns[left] + str(forward)] is None:
                left -= 1
                forward += 1
                if self.columns[left] + str(forward) not in self.squares:
                    break
                moves.append(self.columns[left]+str(forward))
        # ...
        # ...
        # ...
        return moves

    def queen_moves(self, square):
        pass

    def king_moves(self, square):
        pass

    def check(self):
        pass

    def capture(self):
        pass

    def pinned_to_king(self, piece):
        pass

    def promote(self, square):
        pass

    def moves_available(self, square):  # takes a square and returns possible moves
        # Moves for Pawns
        if square in self.pawns:
            return self.pawn_moves(square)
        # Moves for Rooks
        if square in self.rooks:
            return self.rook_moves(square)
        # Moves for Bishops
        if square in self.bishops:
            return self.bishop_moves(square)
        return []

    def move(self, square1, square2):  # takes in two squares in form of strings (ex: move("a3", "a4"))
        if square2 in self.moves_available(square1):  # checking if the move is legal
            self.squares[square2] = self.squares[square1]  # moving our selected piece to selected square
            self.squares[square1] = None  # changing the previous square of our piece to empty

    def print_board(self):
        for row in range(8, 0, -1):
            for col in self.columns:
                square = col + str(row)
                print(square, end=' ')
            print()
        print(self.squares)


my_board = Board()
print(my_board.moves_available("b2"))
print(my_board.moves_available("a1"))
print(my_board.moves_available("h1"))
my_board.print_board()
